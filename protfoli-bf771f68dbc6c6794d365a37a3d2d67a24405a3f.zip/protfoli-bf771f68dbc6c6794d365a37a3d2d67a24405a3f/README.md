# protfoli<Html>
	<hade>
		<title>table form </title>
	</hade>
	<body>
	<marquee>Web Desigine Devlopment- MD: ALIMUL BASHER-Website Design Training </marquee>
				
		<table border="1" cellpadding="10" align="center">
		
		<form>
			<table border="1" cellpadding="10" align="center"><br><br>
			<tr>
				<th colspan="2"> registartion form</th>
			</tr>
			<tr>
				<td>username</td>
					<td>
						<input type="text"placeholder="Enter Username" size="30">
					</td>
			</tr>
			<tr>
				<td>password</td>
				<td>
					<input type="password" placeholder="Enter Password" size="30">
				</td>
			</tr>
			<tr>
				<td>father name</td>
				<td>
					<input type="father name" placeholder="Enter Father name" size="30">
				</td>
			<tr>
			</tr>
				<td>Mother name</td>
				<td>
					<input type="Mother name"placeholder="Enter Mother name" size="30">
				</td>
			</tr>
			<tr> 
				<td> Email</td>
				<td>
					<input type="Email" placeholder="Enter Email" size="30">			
				</td>
			</tr>
			<tr>
				<td> mobile no</td>
				<td>
					<input type=" mobile no"placeholder="enter mobile"Size="30">
				</td>
			</tr>
			<tr>
				<td>address</td>
				<td>
					<textarea cols="30" rows="10" placeholder="enter address"></textarea>
				</td>
			<tr>
				<td colspan="2">
					<input type="submit" value="submit"> 
				</td>
			</tr>
			<tr>
				<td>
					<input type="reset" value="reset">
				</td>
			</tr>
		</form> 
	</body>
</html>
